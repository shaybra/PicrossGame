# Patch Notes

- The console has been moved from under the main frame (as shown in the UI design) to it's left.
- Changed the size of the top and side panels, from 240 to 120 for both.
- Removed the console button and frame from the UI and added it to the chat frame.
- Removed erase